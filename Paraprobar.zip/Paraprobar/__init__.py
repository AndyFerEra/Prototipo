"""Base template for Reflex."""
